# Ivory &amp; Vine Atelier — Boutique Wedding Decor &amp; Floral Styling

A fully self-contained, single-page marketing site for a fictional boutique wedding
decor and floral styling brand. Built as standalone HTML with embedded CSS and JS —
**no backend, no build step, no frameworks.**

## File structure (publish-ready)

```
ivory-and-vine-site/
├── index.html                            # Entry point for hosting (identical to the file below)
├── ivory-and-vine-wedding-decor.html     # Main descriptive copy of the site (same final code)
└── README.md                             # This file
```

`index.html` and `ivory-and-vine-wedding-decor.html` contain the same final code.
Hosts serve `index.html` by default, so it is the file that gets published; the
descriptively named copy is kept for clarity and archival.

## What's inside

- **Self-contained:** one HTML file with all CSS in a `<style>` block and all JS in a `<script>` block.
- **Fonts via CDN:** Fraunces (elegant display serif) + Jost (clean sans), loaded from Google Fonts.
- **Custom inline SVG logo** (leaf + vine + ring mark) and SVG favicon — no image files needed.
- **Gallery + hero + about** use hand-built inline SVG illustration cards, so the page has
  zero external image dependencies and stays fast.
- **Light/dark mode** toggle that works without `localStorage` (in-memory; honours OS preference on load).
- **Accessibility:** skip link, semantic landmarks, labelled form, accessible mobile nav
  (Escape to close, focus management), visible focus states, `prefers-reduced-motion` respected.
- **SEO:** descriptive title, meta description, Open Graph + Twitter card tags.

## Run it locally

Just open the file in a browser:

```bash
open index.html          # macOS
# or simply double-click index.html
```

Optionally serve it over a local web server (closer to production behaviour):

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deployment guide

> **Important:** an HTML file on your computer is **not** public. It only becomes a live
> website once a host serves it over the internet. Until then, share it by sending the file.

### Option A — GitHub Pages (free)
1. Create a repository at github.com and upload all files.
2. **Settings → Pages → Source → `main` branch (root)**.
3. Live at `https://<username>.github.io/<repo>/` within a minute.

### Option B — Netlify (free)
1. Sign up at netlify.com.
2. **Add new site → Deploy manually**, then drag-and-drop the project folder.
3. Live instantly at a `*.netlify.app` URL. Drop in updated files to redeploy.

### Option C — Custom domain
1. Buy a domain (Namecheap, Porkbun, Google Domains, etc.).
2. Add the domain in your host's dashboard.
3. Point the domain's DNS (CNAME / A records) at the host.
4. Enable HTTPS (free on GitHub Pages and Netlify).

A matching **“How to Publish Live”** section is also built into the page itself.

---

*Ivory &amp; Vine Atelier is a fictional brand created for demonstration purposes. All pricing,
testimonials, and contact details are illustrative.*
